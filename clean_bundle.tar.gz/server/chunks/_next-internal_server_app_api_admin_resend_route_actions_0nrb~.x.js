module.exports=[40692,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_resend_route_actions_0nrb~.x.js.map