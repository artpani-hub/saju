module.exports=[10305,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_input_page_actions_0_3htt2.js.map