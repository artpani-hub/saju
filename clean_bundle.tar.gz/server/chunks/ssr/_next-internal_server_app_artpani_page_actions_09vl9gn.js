module.exports=[56011,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_artpani_page_actions_09vl9gn.js.map