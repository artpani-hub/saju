:HL["/_next/static/chunks/0yj1kitcwnbqc.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}},"staleTime":300,"buildId":"Z50j4wpSLx4h6QKC1ZA1D"}
