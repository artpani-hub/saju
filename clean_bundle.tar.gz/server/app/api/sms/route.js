var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/sms/route.js")
R.c("server/chunks/[root-of-the-server]__0gq0hcr._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_sms_route_actions_01_l_td.js")
R.m(95917)
module.exports=R.m(95917).exports
