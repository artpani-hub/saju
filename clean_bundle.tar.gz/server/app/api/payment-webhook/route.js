var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/payment-webhook/route.js")
R.c("server/chunks/[root-of-the-server]__0y.b289._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_payment-webhook_route_actions_0vj2hhq.js")
R.m(52749)
module.exports=R.m(52749).exports
