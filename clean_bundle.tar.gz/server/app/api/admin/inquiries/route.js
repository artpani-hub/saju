var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/inquiries/route.js")
R.c("server/chunks/[root-of-the-server]__0zzl-ku._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_inquiries_route_actions_0a8p9qf.js")
R.m(209)
module.exports=R.m(209).exports
