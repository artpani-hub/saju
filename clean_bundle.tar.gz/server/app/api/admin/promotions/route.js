var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/promotions/route.js")
R.c("server/chunks/[root-of-the-server]__018irzm._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_promotions_route_actions_10_c~oj.js")
R.m(21063)
module.exports=R.m(21063).exports
