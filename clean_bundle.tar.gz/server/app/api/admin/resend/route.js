var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/resend/route.js")
R.c("server/chunks/[root-of-the-server]__0bn2k1m._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/[root-of-the-server]__01jf-z2._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_resend_route_actions_0nrb~.x.js")
R.m(85805)
module.exports=R.m(85805).exports
