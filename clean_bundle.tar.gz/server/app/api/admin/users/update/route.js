var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/users/update/route.js")
R.c("server/chunks/[root-of-the-server]__0u_oxbk._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_users_update_route_actions_0ml2~84.js")
R.m(35148)
module.exports=R.m(35148).exports
