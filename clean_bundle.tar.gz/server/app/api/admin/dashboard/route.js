var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/dashboard/route.js")
R.c("server/chunks/[root-of-the-server]__0ysy5-4._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_dashboard_route_actions_0wbbc8b.js")
R.m(86040)
module.exports=R.m(86040).exports
