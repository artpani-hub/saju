var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/orders/route.js")
R.c("server/chunks/[root-of-the-server]__01ns9rn._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_0in2im8.js")
R.c("server/chunks/_next-internal_server_app_api_orders_route_actions_0qla9fh.js")
R.m(98767)
module.exports=R.m(98767).exports
