var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/email/route.js")
R.c("server/chunks/[root-of-the-server]__0bmz~ga._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/[root-of-the-server]__01jf-z2._.js")
R.c("server/chunks/_next-internal_server_app_api_email_route_actions_0__n7o7.js")
R.m(3900)
module.exports=R.m(3900).exports
