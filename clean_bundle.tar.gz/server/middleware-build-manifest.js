globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/Z50j4wpSLx4h6QKC1ZA1D/_buildManifest.js",
    "static/Z50j4wpSLx4h6QKC1ZA1D/_ssgManifest.js",
    "static/Z50j4wpSLx4h6QKC1ZA1D/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0y_wgo4lu8n.h.js",
    "static/chunks/0bymg5d-lqs0o.js",
    "static/chunks/0m_p1bxtorv5i.js",
    "static/chunks/turbopack-0l84ihoqzmg5m.js"
  ]
};
